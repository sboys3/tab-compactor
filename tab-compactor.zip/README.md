# Firefox Tab Compactor

This is an extension that uses userChrome.css to allow tabs to significantly decrease in size in the toolbar.

I also recommend setting `browser.compactmode.show` to true in about:config and going into `more tools > customize toolbar` and setting the mode to compact for more space savings.


## about:config Options Required for Testing
Without these, Firefox will say the extension is corrupt and won't load. This also requires the nightly build of Firefox.
* xpinstall.signatures.required: false
* extensions.experiments.enabled: true


## Building Extension
Just zip up 'manifest.json', 'userChrome.css' and `icons` folder.